<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qe2";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
} 
$id = $_GET['q'];
$sql = "select name from employee where name like '%".$id."%'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
 while($row = $result->fetch_assoc()) {
 echo $row["name"]. "\n";
 }
} else {
 echo "0 results";
}
$conn->close();
?>