<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_POST["email"];
$pass = $_POST["pass"];


$result = mysqli_query($conn,"SELECT email, password FROM status WHERE email = '$email'");

$row = mysqli_fetch_array($result);


if($row[0]==$email && $row[1]==$pass){
    echo"You are a validated user.";
	 session_start();
	
header("location: welcome");}
else{
echo"Sorry, your credentials are not valid, Please try again.";}


?>